﻿namespace CLMSAPP.Models
{
    public class UserLogin
    {
        public Guid Id { get; set; } 
        public string? Username { get; set; }
    }
}
